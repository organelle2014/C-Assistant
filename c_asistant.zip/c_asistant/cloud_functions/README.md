
## After adding firebase cloud functions code 

Go to functions dashboard from firebase and click on the three dot menu button then click <B>DETAILED USAGE STATS</B> and from the opening webpage click on edit and make these changes<br>

Set runtime as <B>Node.js6</B><br>
Set memory allocation as <B>2gb</B>

## Note

Don't forget to change the <B>click_action</B> from all codes if you modifiy the Android Manifiest.<br>
click_action is used for opening the activity which has that intent.
